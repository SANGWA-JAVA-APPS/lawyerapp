#!/bin/bash

# Test script for JWT authentication
echo "Testing JWT Authentication..."

# Test login endpoint
echo "Testing login with admin credentials..."
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "admin123"
  }' \
  -v

echo ""
echo "Testing login with lawyer credentials..."
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "lawyer",
    "password": "lawyer123"
  }' \
  -v

echo ""
echo "Testing login with client credentials..."
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "client",
    "password": "client123"
  }' \
  -v
