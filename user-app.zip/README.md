# Lawyer App - Spring Boot Application

This is a Spring Boot application for managing lawyer and client accounts with JWT authentication and secure API endpoints.

## Features

- **MySQL Database Integration**: Configured to use MySQL database
- **JPA Entities**: Account and AccountCategory entities with proper relationships
- **JWT Authentication**: Token-based authentication with refresh tokens
- **Swagger UI**: JWT-secured API documentation
- **Default Users**: Pre-configured admin, lawyer, and client users
- **RESTful APIs**: Complete CRUD operations for accounts and categories

## Prerequisites

- Java 17 or higher
- Maven 3.6 or higher
- MySQL 8.0 or higher

## Database Setup

1. Install MySQL Server
2. Create a database named `lawyerapp_db` (or let the application create it automatically)
3. Update the database credentials in `application.properties` if needed:
   ```properties
   spring.datasource.username=your_username
   spring.datasource.password=your_password
   spring.datasource.url=jdbc:mysql://localhost:3306/lawyerapp_db
   ```

## Running the Application

1. Clone the repository
2. Navigate to the project directory
3. Run the application:
   ```bash
   mvn spring-boot:run
   ```

The application will start on port 8080.

## Authentication

The application uses JWT (JSON Web Token) authentication. To access protected endpoints:

1. Login via POST `/api/auth/login` with username and password
2. Use the returned JWT token in the `Authorization` header as `Bearer <token>`

## Default Users

The application creates default users with plain text passwords:

| Username | Password   | Role   |
|----------|------------|--------|
| admin    | admin123   | ADMIN  |
| lawyer   | lawyer123  | LAWYER |
| client   | client123  | CLIENT |

## API Documentation

Access the Swagger UI at: `http://localhost:8080/swagger-ui.html`

### How to use Swagger with JWT:

1. First, login using the `/api/auth/login` endpoint
2. Copy the JWT token from the response
3. Click the "Authorize" button in Swagger UI
4. Enter `Bearer <your-jwt-token>` in the authorization field
5. Now you can access all protected endpoints

## API Endpoints

### Authentication
- `POST /api/auth/login` - Login and get JWT token
- `POST /api/auth/refresh` - Refresh JWT token

### Home
- `GET /` - Application information and usage instructions
- `GET /health` - Health check

### Account Categories (Protected)
- `GET /api/account-categories` - Get all categories
- `GET /api/account-categories/{id}` - Get category by ID
- `POST /api/account-categories` - Create new category

### Accounts (Protected)
- `GET /api/accounts` - Get all accounts
- `GET /api/accounts/{id}` - Get account by ID
- `GET /api/accounts/username/{username}` - Get account by username
- `GET /api/accounts/active` - Get active accounts

## JWT Configuration

The application uses the following JWT settings:
- **Token Expiration**: 24 hours (86400000 ms)
- **Refresh Token Expiration**: 7 days (604800000 ms)
- **Algorithm**: HS512

## Security

- JWT tokens are required for all API endpoints (except auth endpoints)
- Swagger UI is publicly accessible but requires JWT for API testing
- Token refresh mechanism available for continuous authentication

## Technologies Used

- Spring Boot 3.5.3
- Spring Data JPA
- Spring Security with JWT
- MySQL
- Swagger/OpenAPI 3
- JJWT (Java JWT library)
- Lombok
- Maven
