# JWT Authentication Testing Guide

## Steps to Test JWT Authentication

### 1. Start the Application
```bash
cd "d:\Apache\webapps_linux\USB Kingston\SPRING BOOT\lawyerapp"
mvn spring-boot:run
```

### 2. Test Login Endpoint

#### Using curl (Command Line)
```bash
# Test admin login
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "admin", "password": "admin123"}'

# Test lawyer login
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "lawyer", "password": "lawyer123"}'

# Test client login
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"username": "client", "password": "client123"}'
```

#### Using Postman or Swagger UI
1. **URL**: `POST http://localhost:8080/api/auth/login`
2. **Headers**: `Content-Type: application/json`
3. **Body** (raw JSON):
```json
{
  "username": "admin",
  "password": "admin123"
}
```

### 3. Expected Response
```json
{
  "token": "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhZG1pbiIsImlhdCI6MTY...",
  "refreshToken": "eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJhZG1pbiIsImlhdCI6MTY...",
  "username": "admin",
  "email": "admin@lawyerapp.com",
  "role": "ADMIN"
}
```

### 4. Using JWT Token for Protected Endpoints
After successful login, use the JWT token in the Authorization header:

```bash
# Get all accounts (protected endpoint)
curl -X GET http://localhost:8080/api/accounts \
  -H "Authorization: Bearer YOUR_JWT_TOKEN_HERE"
```

### 5. Access Swagger UI
1. Go to: `http://localhost:8080/swagger-ui.html`
2. Click on "Authorize" button
3. In the JWT Bearer token field, enter: `Bearer YOUR_JWT_TOKEN_HERE`
4. Click "Authorize"
5. Now you can test all protected endpoints

### 6. Default Users
| Username | Password   | Role   |
|----------|------------|--------|
| admin    | admin123   | ADMIN  |
| lawyer   | lawyer123  | LAWYER |
| client   | client123  | CLIENT |

### 7. Available Protected Endpoints
- `GET /api/accounts` - Get all accounts
- `GET /api/accounts/{id}` - Get account by ID
- `GET /api/accounts/username/{username}` - Get account by username
- `GET /api/accounts/active` - Get active accounts
- `GET /api/account-categories` - Get all account categories
- `GET /api/account-categories/{id}` - Get account category by ID
- `POST /api/account-categories` - Create new account category

### 8. Public Endpoints (No Authentication Required)
- `GET /` - Application info
- `GET /health` - Health check
- `POST /api/auth/login` - Login
- `POST /api/auth/refresh` - Refresh token

## Troubleshooting

### If you get a 400 Bad Request error:
1. Make sure the request body is valid JSON
2. Check that the username and password are correct
3. Verify the database is running and accessible
4. Check application logs for detailed error messages

### If you get authentication errors:
1. Verify MySQL is running on port 3300
2. Check database connection settings in application.properties
3. Ensure default users were created during startup

### If JWT token is not working:
1. Make sure the token is included in the Authorization header
2. Use the format: `Bearer YOUR_JWT_TOKEN_HERE`
3. Check that the token hasn't expired (24 hours by default)

## Database Connection
Make sure your MySQL database is running with these settings:
- Host: localhost
- Port: 3300
- Database: lawyerapp_db
- Username: sangwa
- Password: A.manigu125
