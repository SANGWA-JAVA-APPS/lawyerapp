package com.bar.lawyerapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LawyerappApplicationTests {

	@Test
	void contextLoads() {
	}

}
