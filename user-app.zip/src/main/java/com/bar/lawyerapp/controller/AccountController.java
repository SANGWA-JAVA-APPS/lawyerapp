package com.bar.lawyerapp.controller;

import com.bar.lawyerapp.dto.AccountDto;
import com.bar.lawyerapp.entity.Account;
import com.bar.lawyerapp.repository.AccountRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/accounts")
@RequiredArgsConstructor
@Tag(name = "Accounts", description = "Account Management API")
@SecurityRequirement(name = "bearerAuth")
public class AccountController {

    private final AccountRepository accountRepository;

    @GetMapping
    @Operation(summary = "Get all accounts", description = "Retrieve all user accounts")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved accounts"),
        @ApiResponse(responseCode = "401", description = "Unauthorized - Authentication required")
    })
    public ResponseEntity<List<AccountDto>> getAllAccounts() {
        List<Account> accounts = accountRepository.findAll();
        List<AccountDto> accountDtos = accounts.stream()
            .map(this::convertToDto)
            .collect(Collectors.toList());
        return ResponseEntity.ok(accountDtos);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get account by ID", description = "Retrieve a specific account by its ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved account"),
        @ApiResponse(responseCode = "404", description = "Account not found"),
        @ApiResponse(responseCode = "401", description = "Unauthorized - Authentication required")
    })
    public ResponseEntity<AccountDto> getAccountById(@PathVariable Long id) {
        return accountRepository.findById(id)
            .map(this::convertToDto)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/username/{username}")
    @Operation(summary = "Get account by username", description = "Retrieve a specific account by its username")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved account"),
        @ApiResponse(responseCode = "404", description = "Account not found"),
        @ApiResponse(responseCode = "401", description = "Unauthorized - Authentication required")
    })
    public ResponseEntity<AccountDto> getAccountByUsername(@PathVariable String username) {
        return accountRepository.findByUsername(username)
            .map(this::convertToDto)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/active")
    @Operation(summary = "Get active accounts", description = "Retrieve all active user accounts")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved active accounts"),
        @ApiResponse(responseCode = "401", description = "Unauthorized - Authentication required")
    })
    public ResponseEntity<List<AccountDto>> getActiveAccounts() {
        List<Account> accounts = accountRepository.findByActiveTrue();
        List<AccountDto> accountDtos = accounts.stream()
            .map(this::convertToDto)
            .collect(Collectors.toList());
        return ResponseEntity.ok(accountDtos);
    }

    private AccountDto convertToDto(Account account) {
        return new AccountDto(
            account.getId(),
            account.getUsername(),
            account.getEmail(),
            account.getFullName(),
            account.getPhoneNumber(),
            account.isActive(),
            account.getCreatedAt(),
            account.getUpdatedAt(),
            account.getAccountCategory().getName()
        );
    }
}
