package com.bar.lawyerapp.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/")
@Tag(name = "Home", description = "Application Information API")
public class HomeController {

    @GetMapping
    @Operation(summary = "Get application info", description = "Get basic application information and status")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved application info")
    })
    public Map<String, Object> home() {
        Map<String, Object> response = new HashMap<>();
        response.put("application", "Lawyer App");
        response.put("version", "1.0.0");
        response.put("status", "Running");
        response.put("swagger-ui", "/swagger-ui.html");
        response.put("api-docs", "/api-docs");
        response.put("authentication", "JWT Bearer Token");
        response.put("login-endpoint", "/api/auth/login");
        response.put("default-users", Map.of(
            "admin", "admin123",
            "lawyer", "lawyer123",
            "client", "client123"
        ));
        response.put("instructions", Map.of(
            "step1", "Login via POST /api/auth/login with username and password",
            "step2", "Copy the JWT token from the response",
            "step3", "Use the token in Swagger UI by clicking 'Authorize' and entering 'Bearer <your-token>'"
        ));
        return response;
    }

    @GetMapping("/health")
    @Operation(summary = "Health check", description = "Check if the application is healthy")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Application is healthy")
    })
    public Map<String, String> health() {
        Map<String, String> response = new HashMap<>();
        response.put("status", "UP");
        response.put("timestamp", java.time.LocalDateTime.now().toString());
        return response;
    }
}
