package com.bar.lawyerapp.controller;

import com.bar.lawyerapp.dto.AccountCategoryDto;
import com.bar.lawyerapp.entity.AccountCategory;
import com.bar.lawyerapp.repository.AccountCategoryRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/account-categories")
@RequiredArgsConstructor
@Tag(name = "Account Categories", description = "Account Category Management API")
@SecurityRequirement(name = "bearerAuth")
public class AccountCategoryController {

    private final AccountCategoryRepository accountCategoryRepository;

    @GetMapping
    @Operation(summary = "Get all account categories", description = "Retrieve all account categories with account counts")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved account categories"),
        @ApiResponse(responseCode = "401", description = "Unauthorized - Authentication required")
    })
    public ResponseEntity<List<AccountCategoryDto>> getAllCategories() {
        List<AccountCategory> categories = accountCategoryRepository.findAll();
        List<AccountCategoryDto> categoryDtos = categories.stream()
            .map(this::convertToDto)
            .collect(Collectors.toList());
        return ResponseEntity.ok(categoryDtos);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get account category by ID", description = "Retrieve a specific account category by its ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Successfully retrieved account category"),
        @ApiResponse(responseCode = "404", description = "Account category not found"),
        @ApiResponse(responseCode = "401", description = "Unauthorized - Authentication required")
    })
    public ResponseEntity<AccountCategoryDto> getCategoryById(@PathVariable Long id) {
        return accountCategoryRepository.findById(id)
            .map(this::convertToDto)
            .map(ResponseEntity::ok)
            .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    @Operation(summary = "Create new account category", description = "Create a new account category")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Account category created successfully"),
        @ApiResponse(responseCode = "400", description = "Invalid input data"),
        @ApiResponse(responseCode = "401", description = "Unauthorized - Authentication required")
    })
    public ResponseEntity<AccountCategoryDto> createCategory(@RequestBody AccountCategory category) {
        AccountCategory savedCategory = accountCategoryRepository.save(category);
        return ResponseEntity.ok(convertToDto(savedCategory));
    }

    private AccountCategoryDto convertToDto(AccountCategory category) {
        return new AccountCategoryDto(
            category.getId(),
            category.getName(),
            category.getDescription(),
            category.getAccounts().size()
        );
    }
}
