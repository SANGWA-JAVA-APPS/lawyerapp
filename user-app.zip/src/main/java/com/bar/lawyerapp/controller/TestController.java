package com.bar.lawyerapp.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/test")
@Tag(name = "Test", description = "Test API for JWT Authentication")
@SecurityRequirement(name = "bearerAuth")
@Slf4j
public class TestController {

    @GetMapping("/auth")
    @Operation(summary = "Test authentication", description = "Test if JWT authentication is working")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Authentication successful"),
        @ApiResponse(responseCode = "401", description = "Unauthorized"),
        @ApiResponse(responseCode = "403", description = "Forbidden")
    })
    public ResponseEntity<Map<String, Object>> testAuth() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        
        log.info("Test endpoint - Authentication: {}", authentication);
        log.info("Test endpoint - Principal: {}", authentication != null ? authentication.getPrincipal() : "null");
        log.info("Test endpoint - Authorities: {}", authentication != null ? authentication.getAuthorities() : "null");
        log.info("Test endpoint - Is authenticated: {}", authentication != null ? authentication.isAuthenticated() : false);
        
        Map<String, Object> response = new HashMap<>();
        response.put("authenticated", authentication != null && authentication.isAuthenticated());
        response.put("principal", authentication != null ? authentication.getName() : "null");
        response.put("authorities", authentication != null ? authentication.getAuthorities() : "null");
        response.put("message", "JWT Authentication is working!");
        
        return ResponseEntity.ok(response);
    }

    @GetMapping("/public")
    @Operation(summary = "Test public endpoint", description = "Test public endpoint that doesn't require authentication")
    public ResponseEntity<Map<String, String>> testPublic() {
        Map<String, String> response = new HashMap<>();
        response.put("message", "Public endpoint works!");
        response.put("timestamp", java.time.LocalDateTime.now().toString());
        return ResponseEntity.ok(response);
    }
}
