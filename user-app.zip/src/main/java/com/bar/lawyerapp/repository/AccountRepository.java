package com.bar.lawyerapp.repository;

import com.bar.lawyerapp.entity.Account;
import com.bar.lawyerapp.entity.AccountCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Repository
@Transactional(readOnly = true)
public interface AccountRepository extends JpaRepository<Account, Long> {
    
    @Query("SELECT a FROM Account a JOIN FETCH a.accountCategory WHERE a.username = :username")
    Optional<Account> findByUsername(@Param("username") String username);
    
    @Query("SELECT a FROM Account a JOIN FETCH a.accountCategory WHERE a.email = :email")
    Optional<Account> findByEmail(@Param("email") String email);
    
    List<Account> findByAccountCategory(AccountCategory accountCategory);
    boolean existsByUsername(String username);
    boolean existsByEmail(String email);
    
    @Query("SELECT a FROM Account a JOIN FETCH a.accountCategory WHERE a.active = true")
    List<Account> findByActiveTrue();
}
