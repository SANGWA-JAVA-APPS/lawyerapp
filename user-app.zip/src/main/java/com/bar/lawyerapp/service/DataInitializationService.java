package com.bar.lawyerapp.service;

import com.bar.lawyerapp.entity.Account;
import com.bar.lawyerapp.entity.AccountCategory;
import com.bar.lawyerapp.repository.AccountCategoryRepository;
import com.bar.lawyerapp.repository.AccountRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class DataInitializationService implements CommandLineRunner {

    private final AccountCategoryRepository accountCategoryRepository;
    private final AccountRepository accountRepository;

    @Override
    public void run(String... args) throws Exception {
        log.info("Starting data initialization...");
        
        // Create Account Categories
        AccountCategory adminCategory = createCategoryIfNotExists("ADMIN", "System Administrator Category");
        AccountCategory lawyerCategory = createCategoryIfNotExists("LAWYER", "Legal Professional Category");
        AccountCategory clientCategory = createCategoryIfNotExists("CLIENT", "Client Category");
        
        // Create Default Accounts
        createAccountIfNotExists("admin", "admin123", "admin@lawyerapp.com", 
            "System Administrator", "+1234567890", adminCategory);
        
        createAccountIfNotExists("lawyer", "lawyer123", "lawyer@lawyerapp.com", 
            "John Doe", "+1234567891", lawyerCategory);
        
        createAccountIfNotExists("client", "client123", "client@lawyerapp.com", 
            "Jane Smith", "+1234567892", clientCategory);
        
        log.info("Data initialization completed successfully!");
        log.info("Default users created:");
        log.info("- admin/admin123 (ADMIN)");
        log.info("- lawyer/lawyer123 (LAWYER)");
        log.info("- client/client123 (CLIENT)");
    }
    
    private AccountCategory createCategoryIfNotExists(String name, String description) {
        return accountCategoryRepository.findByName(name)
            .orElseGet(() -> {
                AccountCategory category = new AccountCategory(name, description);
                AccountCategory saved = accountCategoryRepository.save(category);
                log.info("Created account category: {}", name);
                return saved;
            });
    }
    
    private Account createAccountIfNotExists(String username, String password, String email, 
                                           String fullName, String phoneNumber, AccountCategory category) {
        return accountRepository.findByUsername(username)
            .orElseGet(() -> {
                Account account = new Account(username, password, email, fullName, phoneNumber, category);
                Account saved = accountRepository.save(account);
                log.info("Created account: {} ({})", username, category.getName());
                return saved;
            });
    }
}
