package com.bar.lawyerapp.filter;

import com.bar.lawyerapp.util.JwtUtils;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
@RequiredArgsConstructor
@Slf4j
public class AuthTokenFilter extends OncePerRequestFilter {

    private final JwtUtils jwtUtils;
    private final UserDetailsService userDetailsService;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, 
                                  FilterChain filterChain) throws ServletException, IOException {
        
        String requestPath = request.getRequestURI();
        log.debug("JWT Filter - Processing request: {} {}", request.getMethod(), requestPath);
        
        // Skip JWT validation for auth endpoints and public endpoints
        if (shouldSkipFilter(requestPath)) {
            log.debug("JWT Filter - Skipping JWT validation for path: {}", requestPath);
            filterChain.doFilter(request, response);
            return;
        }
        
        try {
            String jwt = parseJwt(request);
            log.debug("JWT Filter - JWT token found: {}", jwt != null ? "Yes" : "No");
            
            if (jwt != null && jwtUtils.validateJwtToken(jwt)) {
                String username = jwtUtils.getUserNameFromJwtToken(jwt);
                log.debug("JWT Filter - JWT token valid for user: {}", username);

                try {
                    UserDetails userDetails = userDetailsService.loadUserByUsername(username);
                    log.debug("JWT Filter - User details loaded for: {}, authorities: {}", username, userDetails.getAuthorities());
                    
                    if (jwtUtils.validateToken(jwt, userDetails)) {
                        UsernamePasswordAuthenticationToken authentication = 
                            new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
                        authentication.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

                        SecurityContextHolder.getContext().setAuthentication(authentication);
                        log.debug("JWT Filter - Authentication set successfully for user: {} with authorities: {}", 
                            username, userDetails.getAuthorities());
                    } else {
                        log.warn("JWT Filter - JWT token validation failed for user: {}", username);
                    }
                } catch (Exception e) {
                    log.error("JWT Filter - Error loading user details for user {}: {}", username, e.getMessage());
                }
            } else {
                log.warn("JWT Filter - JWT token is null or invalid");
            }
        } catch (Exception e) {
            log.error("JWT Filter - Cannot set user authentication: {}", e.getMessage(), e);
        }

        filterChain.doFilter(request, response);
    }

    private boolean shouldSkipFilter(String requestPath) {
        return requestPath.equals("/api/auth/login") || 
               requestPath.equals("/api/auth/register") ||
               requestPath.equals("/api/test/public") ||
               requestPath.equals("/") ||
               requestPath.equals("/health") ||
               requestPath.startsWith("/swagger-ui") ||
               requestPath.startsWith("/v3/api-docs") ||
               requestPath.startsWith("/api-docs");
    }

    private String parseJwt(HttpServletRequest request) {
        String headerAuth = request.getHeader("Authorization");
        log.debug("JWT Filter - Authorization header: {}", headerAuth);

        if (StringUtils.hasText(headerAuth) && headerAuth.startsWith("Bearer ")) {
            String token = headerAuth.substring(7);
            log.debug("JWT Filter - Extracted JWT token: {}", token.substring(0, Math.min(token.length(), 20)) + "...");
            return token;
        }

        log.debug("JWT Filter - No valid Authorization header found");
        return null;
    }
}
