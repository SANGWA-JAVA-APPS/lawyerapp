import { useState } from 'react'
import ProtectedRoute from './components/ProtectedRoute'
import Dashboard from './components/Dashboard'
import { authService } from './services/apiService'
import './App.css'

function App() {
  const [user, setUser] = useState(null)

  const handleLogin = (userData) => {
    setUser(userData)
  }

  return (
    <ProtectedRoute onLogin={handleLogin}>
      <Dashboard />
    </ProtectedRoute>
  )
}

export default App
