import { Card, Table, Badge } from 'react-bootstrap'

const PaymentsTable = () => {
  // Sample data for payments
  const payments = [
    { id: 1, client: 'John Smith', amount: '$5,000', status: 'Paid', date: '2024-01-15' },
    { id: 2, client: 'Jane Doe', amount: '$3,500', status: 'Pending', date: '2024-01-20' },
    { id: 3, client: 'Bob Wilson', amount: '$2,000', status: 'Overdue', date: '2024-01-10' }
  ]

  const getStatusVariant = (status) => {
    switch (status.toLowerCase()) {
      case 'paid':
        return 'success'
      case 'pending':
        return 'warning'
      case 'overdue':
        return 'danger'
      default:
        return 'primary'
    }
  }

  return (
    <Card>
      <Card.Header>
        <h4 className="mb-0">Payments Management</h4>
      </Card.Header>
      <Card.Body>
        <Table striped bordered hover responsive>
          <thead>
            <tr>
              <th>Client</th>
              <th>Amount</th>
              <th>Status</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {payments.map(payment => (
              <tr key={payment.id}>
                <td>{payment.client}</td>
                <td><strong>{payment.amount}</strong></td>
                <td>
                  <Badge bg={getStatusVariant(payment.status)}>
                    {payment.status}
                  </Badge>
                </td>
                <td>{payment.date}</td>
              </tr>
            ))}
          </tbody>
        </Table>
      </Card.Body>
    </Card>
  )
}

export default PaymentsTable
