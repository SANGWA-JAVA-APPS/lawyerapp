import { useState, useEffect } from 'react'
import { Container, Row, Col, Alert, Button, Badge, Modal } from 'react-bootstrap'
import { authService, apiService } from '../services/apiService'
import StatisticsCards from './StatisticsCards'
import NavigationTabs from './NavigationTabs'

const Dashboard = () => {
  const [user, setUser] = useState(null)
  const [showLogoutModal, setShowLogoutModal] = useState(false)
  const [backendData, setBackendData] = useState({
    accounts: [],
    categories: [],
    loading: false,
    error: null
  })

  // Check if user is already logged in
  useEffect(() => {
    if (authService.isAuthenticatedBasic()) {
      const username = authService.getUsername()
      const userRole = authService.getUserRole()
      setUser({ username, role: userRole })
      fetchBackendData()
    }
  }, [])

  // Fetch data from backend
  const fetchBackendData = async () => {
    setBackendData(prev => ({ ...prev, loading: true, error: null }))
    
    try {
      const [accounts, categories] = await Promise.all([
        apiService.getAccounts(),
        apiService.getAccountCategories()
      ])
      
      setBackendData({
        accounts,
        categories,
        loading: false,
        error: null
      })
    } catch (error) {
      setBackendData(prev => ({
        ...prev,
        loading: false,
        error: 'Failed to fetch data from backend. Using sample data.'
      }))
      console.error('Backend fetch error:', error)
    }
  }

  const handleLogout = async () => {
    try {
      // Clear all authentication data
      await authService.logout()
      // Reset local state
      setUser(null)
      setBackendData({
        accounts: [],
        categories: [],
        loading: false,
        error: null
      })
    } catch (error) {
      console.error('Logout error:', error)
      // Even if logout fails on backend, clear frontend
      authService.logout()
    }
  }

  const confirmLogout = () => {
    setShowLogoutModal(true)
  }

  const handleConfirmLogout = () => {
    setShowLogoutModal(false)
    handleLogout()
  }

  return (
    <Container fluid className="py-4">
      <Row className="mb-4">
        <Col>
          <Alert variant="primary" className="mb-0 d-flex justify-content-between align-items-center">
            <div>
              <Alert.Heading>NKUNGANIRE LAWYER APP</Alert.Heading>
              <p className="mb-0">Manage your clients, cases, and payments efficiently</p>
            </div>              <div className="text-end">
                <div className="mb-2">
                  <small>Welcome, <strong>{user?.username}</strong></small><br />
                  <small>Role: <Badge bg="secondary">{user?.role}</Badge></small>
                </div>
                <Button variant="outline-light" size="sm" onClick={confirmLogout}>
                  Logout
                </Button>
              </div>
            </Alert>
          </Col>
        </Row>

        {/* Logout Confirmation Modal */}
        <Modal show={showLogoutModal} onHide={() => setShowLogoutModal(false)} centered>
          <Modal.Header closeButton>
            <Modal.Title>Confirm Logout</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            Are you sure you want to logout?
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowLogoutModal(false)}>
              Cancel
            </Button>
            <Button variant="primary" onClick={handleConfirmLogout}>
              Logout
            </Button>
          </Modal.Footer>
        </Modal>

      <StatisticsCards backendData={backendData} />
      <NavigationTabs backendData={backendData} />
    </Container>
  )
}

export default Dashboard
