import { Card, Table, Badge, Alert, Spinner } from 'react-bootstrap'

const ClientsTable = ({ backendData }) => {
  // Sample data for fallback
  const fallbackClients = [
    { id: 1, name: 'John Smith', email: 'john@example.com', phone: '+1234567890', status: 'Active' },
    { id: 2, name: 'Jane Doe', email: 'jane@example.com', phone: '+1234567891', status: 'Active' },
    { id: 3, name: 'Bob Wilson', email: 'bob@example.com', phone: '+1234567892', status: 'Inactive' }
  ]

  const getStatusVariant = (status) => {
    switch (status.toLowerCase()) {
      case 'active':
        return 'success'
      case 'inactive':
        return 'danger'
      default:
        return 'primary'
    }
  }

  // Filter accounts by CLIENT category from backend data
  const clientAccounts = backendData.accounts.filter(account => 
    account.categoryName === 'CLIENT'
  )
  
  const displayClients = clientAccounts.length > 0 ? clientAccounts : fallbackClients

  return (
    <Card>
      <Card.Header className="d-flex justify-content-between align-items-center">
        <h4 className="mb-0">Clients Management</h4>
        {backendData.loading && <Spinner animation="border" size="sm" />}
      </Card.Header>
      <Card.Body>
        {backendData.error && (
          <Alert variant="warning" className="mb-3">
            {backendData.error}
          </Alert>
        )}
        <Table striped bordered hover responsive>
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Username</th>
              <th>Status</th>
              <th>Created</th>
            </tr>
          </thead>
          <tbody>
            {displayClients.map(client => (
              <tr key={client.id}>
                <td>{client.fullName || client.name}</td>
                <td>{client.email}</td>
                <td>{client.phoneNumber || client.phone}</td>
                <td>{client.username || 'N/A'}</td>
                <td>
                  <Badge bg={getStatusVariant(client.active !== undefined ? (client.active ? 'Active' : 'Inactive') : client.status)}>
                    {client.active !== undefined ? (client.active ? 'Active' : 'Inactive') : client.status}
                  </Badge>
                </td>
                <td>{client.createdAt ? new Date(client.createdAt).toLocaleDateString() : 'N/A'}</td>
              </tr>
            ))}
          </tbody>
        </Table>
      </Card.Body>
    </Card>
  )
}

export default ClientsTable
