import { useState } from 'react'
import { Row, Col, Nav, Tab } from 'react-bootstrap'
import LawyersTable from './LawyersTable'
import ClientsTable from './ClientsTable'
import CasesTable from './CasesTable'
import PaymentsTable from './PaymentsTable'

const NavigationTabs = ({ backendData }) => {
  const [activeTab, setActiveTab] = useState('lawyers')

  return (
    <Tab.Container activeKey={activeTab} onSelect={setActiveTab}>
      <Row>
        <Col sm={3}>
          <Nav variant="pills" className="flex-column">
            <Nav.Item>
              <Nav.Link eventKey="lawyers">
                ⚖️ Lawyers
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="clients">
                👥 Clients
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="cases">
                📋 Cases
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="payments">
                💳 Payments
              </Nav.Link>
            </Nav.Item>
          </Nav>
        </Col>
        <Col sm={9}>
          <Tab.Content>
            <Tab.Pane eventKey="lawyers">
              <LawyersTable backendData={backendData} />
            </Tab.Pane>
            <Tab.Pane eventKey="clients">
              <ClientsTable backendData={backendData} />
            </Tab.Pane>
            <Tab.Pane eventKey="cases">
              <CasesTable />
            </Tab.Pane>
            <Tab.Pane eventKey="payments">
              <PaymentsTable />
            </Tab.Pane>
          </Tab.Content>
        </Col>
      </Row>
    </Tab.Container>
  )
}

export default NavigationTabs
