import { Card, Table, Badge, Alert, Spinner } from 'react-bootstrap'

const LawyersTable = ({ backendData }) => {
  // Sample data for fallback
  const fallbackLawyers = [
    { id: 1, name: 'Alice Johnson', email: 'alice@law.com', phone: '+1234567880', specialization: 'Criminal Law', barNumber: 'BAR12345', status: 'Active' },
    { id: 2, name: 'Robert Brown', email: 'robert@law.com', phone: '+1234567881', specialization: 'Corporate Law', barNumber: 'BAR12346', status: 'Active' },
    { id: 3, name: 'Emily Davis', email: 'emily@law.com', phone: '+1234567882', specialization: 'Family Law', barNumber: 'BAR12347', status: 'On Leave' }
  ]

  const getStatusVariant = (status) => {
    switch (status.toLowerCase()) {
      case 'active':
        return 'success'
      case 'inactive':
        return 'danger'
      case 'on leave':
        return 'info'
      default:
        return 'primary'
    }
  }

  // Filter accounts by LAWYER category from backend data
  const lawyerAccounts = backendData.accounts.filter(account => 
    account.categoryName === 'LAWYER'
  )
  
  const displayLawyers = lawyerAccounts.length > 0 ? lawyerAccounts : fallbackLawyers

  return (
    <Card>
      <Card.Header className="d-flex justify-content-between align-items-center">
        <h4 className="mb-0">Lawyers Management</h4>
        {backendData.loading && <Spinner animation="border" size="sm" />}
      </Card.Header>
      <Card.Body>
        {backendData.error && (
          <Alert variant="warning" className="mb-3">
            {backendData.error}
          </Alert>
        )}
        <Table striped bordered hover responsive>
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Username</th>
              <th>Status</th>
              <th>Created</th>
            </tr>
          </thead>
          <tbody>
            {displayLawyers.map(lawyer => (
              <tr key={lawyer.id}>
                <td>{lawyer.fullName || lawyer.name}</td>
                <td>{lawyer.email}</td>
                <td>{lawyer.phoneNumber || lawyer.phone}</td>
                <td>{lawyer.username || 'N/A'}</td>
                <td>
                  <Badge bg={getStatusVariant(lawyer.active !== undefined ? (lawyer.active ? 'Active' : 'Inactive') : lawyer.status)}>
                    {lawyer.active !== undefined ? (lawyer.active ? 'Active' : 'Inactive') : lawyer.status}
                  </Badge>
                </td>
                <td>{lawyer.createdAt ? new Date(lawyer.createdAt).toLocaleDateString() : 'N/A'}</td>
              </tr>
            ))}
          </tbody>
        </Table>
      </Card.Body>
    </Card>
  )
}

export default LawyersTable
