import { Card, Table, Badge } from 'react-bootstrap'

const CasesTable = () => {
  // Sample data for cases
  const cases = [
    { id: 1, title: 'Personal Injury Case', client: 'John Smith', lawyer: 'Alice Johnson', status: 'In Progress', date: '2024-01-15' },
    { id: 2, title: 'Contract Dispute', client: 'Jane Doe', lawyer: 'Robert Brown', status: 'Pending', date: '2024-01-20' },
    { id: 3, title: 'Employment Law', client: 'Bob Wilson', lawyer: 'Emily Davis', status: 'Closed', date: '2024-01-10' }
  ]

  const getStatusVariant = (status) => {
    switch (status.toLowerCase()) {
      case 'in progress':
        return 'warning'
      case 'pending':
        return 'info'
      case 'closed':
        return 'secondary'
      default:
        return 'primary'
    }
  }

  return (
    <Card>
      <Card.Header>
        <h4 className="mb-0">Cases Management</h4>
      </Card.Header>
      <Card.Body>
        <Table striped bordered hover responsive>
          <thead>
            <tr>
              <th>Case Title</th>
              <th>Client</th>
              <th>Lawyer</th>
              <th>Status</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            {cases.map(case_ => (
              <tr key={case_.id}>
                <td>{case_.title}</td>
                <td>{case_.client}</td>
                <td>{case_.lawyer}</td>
                <td>
                  <Badge bg={getStatusVariant(case_.status)}>
                    {case_.status}
                  </Badge>
                </td>
                <td>{case_.date}</td>
              </tr>
            ))}
          </tbody>
        </Table>
      </Card.Body>
    </Card>
  )
}

export default CasesTable
