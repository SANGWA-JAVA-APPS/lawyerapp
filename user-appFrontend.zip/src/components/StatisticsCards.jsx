import { Row, Col, Card } from 'react-bootstrap'

const StatisticsCards = ({ backendData }) => {
  // Sample data for fallback
  const fallbackData = {
    lawyers: 3,
    clients: 3,
    activeCases: 1,
    pendingPayments: 1
  }

  const lawyerCount = backendData.accounts.filter(a => a.categoryName === 'LAWYER').length || fallbackData.lawyers
  const clientCount = backendData.accounts.filter(a => a.categoryName === 'CLIENT').length || fallbackData.clients
  const activeCasesCount = fallbackData.activeCases // This would come from a cases API
  const pendingPaymentsCount = fallbackData.pendingPayments // This would come from a payments API

  return (
    <Row className="mb-4">
      <Col md={3}>
        <Card bg="primary" text="white">
          <Card.Body>
            <Card.Title>Total Lawyers</Card.Title>
            <Card.Text>
              <h2>{lawyerCount}</h2>
            </Card.Text>
          </Card.Body>
        </Card>
      </Col>
      <Col md={3}>
        <Card bg="info" text="white">
          <Card.Body>
            <Card.Title>Total Clients</Card.Title>
            <Card.Text>
              <h2>{clientCount}</h2>
            </Card.Text>
          </Card.Body>
        </Card>
      </Col>
      <Col md={3}>
        <Card bg="success" text="white">
          <Card.Body>
            <Card.Title>Active Cases</Card.Title>
            <Card.Text>
              <h2>{activeCasesCount}</h2>
            </Card.Text>
          </Card.Body>
        </Card>
      </Col>
      <Col md={3}>
        <Card bg="warning" text="white">
          <Card.Body>
            <Card.Title>Pending Payments</Card.Title>
            <Card.Text>
              <h2>{pendingPaymentsCount}</h2>
            </Card.Text>
          </Card.Body>
        </Card>
      </Col>
    </Row>
  )
}

export default StatisticsCards
