import axios from 'axios'
import Cookies from 'js-cookie'

const API_BASE_URL = 'http://localhost:8080'

// Create axios instance with default config
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    const token = Cookies.get('authToken')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

// Response interceptor to handle token expiration
api.interceptors.response.use(
  (response) => {
    return response
  },
  (error) => {
    if (error.response?.status === 401) {
      // Token expired or invalid
      Cookies.remove('authToken')
      Cookies.remove('userRole')
      window.location.href = '/login'
    }
    return Promise.reject(error)
  }
)

// Authentication functions
export const authService = {
  login: async (username, password) => {
    try {
      const response = await api.post('/api/auth/login', {
        username,
        password,
      })
      
      if (response.data.token) {
        Cookies.set('authToken', response.data.token, { expires: 7 })
        Cookies.set('userRole', response.data.role, { expires: 7 })
        Cookies.set('username', username, { expires: 7 })
        return {
          success: true,
          user: response.data,
        }
      }
      return { success: false, message: 'Invalid credentials' }
    } catch (error) {
      return {
        success: false,
        message: error.response?.data?.message || 'Login failed',
      }
    }
  },

  logout: async () => {
    try {
      const credentials = Cookies.get('authCredentials')
      if (credentials) {
        // Call backend logout endpoint
        await axios.post(`${API_BASE_URL}/api/auth/logout`, {}, {
          headers: {
            'Authorization': `Basic ${credentials}`,
          },
        })
      }
    } catch (error) {
      console.error('Logout error:', error)
    } finally {
      // Always clear local storage regardless of backend response
      Cookies.remove('authToken')
      Cookies.remove('userRole')
      Cookies.remove('username')
      Cookies.remove('authCredentials')
      // Force a page refresh to clear any cached data
      window.location.reload()
    }
  },

  isAuthenticated: () => {
    return !!Cookies.get('authToken')
  },

  getUserRole: () => {
    return Cookies.get('userRole')
  },

  getUsername: () => {
    return Cookies.get('username')
  },

  // For basic auth (temporary until JWT is implemented)
  loginBasic: async (username, password) => {
    try {
      const credentials = btoa(`${username}:${password}`)
      const response = await axios.get(`${API_BASE_URL}/api/accounts/username/${username}`, {
        headers: {
          'Authorization': `Basic ${credentials}`,
        },
      })
      
      if (response.data) {
        Cookies.set('authCredentials', credentials, { expires: 7 })
        Cookies.set('userRole', response.data.categoryName, { expires: 7 })
        Cookies.set('username', username, { expires: 7 })
        return {
          success: true,
          user: response.data,
        }
      }
      return { success: false, message: 'Invalid credentials' }
    } catch (error) {
      return {
        success: false,
        message: error.response?.data?.message || 'Login failed',
      }
    }
  },

  isAuthenticatedBasic: () => {
    return !!Cookies.get('authCredentials')
  },
}

// API service functions
export const apiService = {
  // Lawyers
  getLawyers: async () => {
    try {
      const credentials = Cookies.get('authCredentials')
      const response = await axios.get(`${API_BASE_URL}/api/account-categories`, {
        headers: {
          'Authorization': `Basic ${credentials}`,
        },
      })
      return response.data
    } catch (error) {
      console.error('Error fetching lawyers:', error)
      throw error
    }
  },

  // Clients
  getClients: async () => {
    try {
      const credentials = Cookies.get('authCredentials')
      const response = await axios.get(`${API_BASE_URL}/api/accounts`, {
        headers: {
          'Authorization': `Basic ${credentials}`,
        },
      })
      return response.data
    } catch (error) {
      console.error('Error fetching clients:', error)
      throw error
    }
  },

  // Account Categories
  getAccountCategories: async () => {
    try {
      const credentials = Cookies.get('authCredentials')
      const response = await axios.get(`${API_BASE_URL}/api/account-categories`, {
        headers: {
          'Authorization': `Basic ${credentials}`,
        },
      })
      return response.data
    } catch (error) {
      console.error('Error fetching account categories:', error)
      throw error
    }
  },

  // Accounts
  getAccounts: async () => {
    try {
      const credentials = Cookies.get('authCredentials')
      const response = await axios.get(`${API_BASE_URL}/api/accounts`, {
        headers: {
          'Authorization': `Basic ${credentials}`,
        },
      })
      return response.data
    } catch (error) {
      console.error('Error fetching accounts:', error)
      throw error
    }
  },

  getAccountByUsername: async (username) => {
    try {
      const credentials = Cookies.get('authCredentials')
      const response = await axios.get(`${API_BASE_URL}/api/accounts/username/${username}`, {
        headers: {
          'Authorization': `Basic ${credentials}`,
        },
      })
      return response.data
    } catch (error) {
      console.error('Error fetching account:', error)
      throw error
    }
  },

  // Health check
  healthCheck: async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/health`)
      return response.data
    } catch (error) {
      console.error('Error checking health:', error)
      throw error
    }
  },
}

export default api
